#include <fstream>
#include <iostream>
#include <string>
#include <cstdlib>
using namespace std;

ifstream fok("ec.ok");
ifstream fout("ec.out");

void Msg(int pct, string msg )
{
    cout << pct << ' ' << msg;
    try
    {
        fok.close();
        fout.close();
    }
    catch (string ex) {}
    exit(0);
}

int main(int argc, char* argv[])
{
    if ( !fout )
        Msg(0, "Nu exista fisierul ec.out!");

//    int testNumber, testPoints;
//   testNumber = atoi(argv[1]);           // numarul testului
//    testPoints = atoi(argv[2]);           // nr puncte/test

    int total = 0;    // punctajul total
    // doua cerinte, punctaje partiale
    long a, b, c, d;   // valori corecte
    long x, y, z, u;   // valorile concurentului

    bool ok1 = false, ok2 = false, ok3 = false, ok4 = false;
    fok >> a;
    fok >> b;
	fok >> c;
	fok >> d;
    if ( !(fout >> x) )   // daca nu pot citi din fisier
        Msg(0, "Incorect !");

    if ( a == x )
    {
        total += (10 * 10) / 100;  // 10 % din punctajul pe test
        ok1 = true;
    }
    fout >> y;

    if ( b == y )
    {
        total += (10 * 20) / 100; // 80 % din punctaj
        ok2 = true;
    }
	
	fout >> z;

    if ( c == z )
    {
        total += (10 * 30) / 100; // 80 % din punctaj
        ok3 = true;
    }
	
	fout >> u;

    if ( d == u )
    {
        total += (10 * 40) / 100; // 80 % din punctaj
        ok4 = true;
    }
	

    if ( ok1 && ok2 && ok3 && ok4 )
       Msg(total, "Corect !");
    if (!ok1 && !ok2 && !ok3 && !ok4)
        Msg(total, "Incorect !" );
    if ( ok1 && ok2 && ok3 )
        Msg(total, "tip I OK, sol tip I OK, tip II OK, sol tip II NO !");
    if ( ok1 && ok2 && ok4 )
        Msg(total, "tip I OK, sol tip I OK, tip II NO, sol tip II OK !");
    if ( ok1 && ok3 && ok4 )
        Msg(total, "tip I OK, sol tip I NO, tip II OK, sol tip II OK !");
	if ( ok2 && ok3 && ok4 )
        Msg(total, "tip I NO, sol tip I OK, tip II OK, sol tip II OK !");
	if(ok1 && ok2)
        Msg(total, "tip I OK, sol tip I OK, tip II NO, sol tip II NO !");
	if(ok1 && ok3)
        Msg(total, "tip I OK, sol tip I NO, tip II OK, sol tip II NO !");
	if(ok1 && ok4)
        Msg(total, "tip I OK, sol tip I NO, tip II NO, sol tip II OK !");
	if(ok2 && ok3)
        Msg(total, "tip I NO, sol tip I OK, tip II OK, sol tip II NO !");
	if(ok2 && ok4)
        Msg(total, "tip I NO, sol tip I OK, tip II NO, sol tip II OK !");
	if(ok3 && ok4)
        Msg(total, "tip I NO, sol tip I NO, tip II OK, sol tip II OK !");
	if(ok1)
		Msg(total, "tip I OK, sol tip I NO, tip II NO, sol tip II NO !");
	if(ok2)
		Msg(total, "tip I NO, sol tip I OK, tip II NO, sol tip II NO !");
	if(ok3)
		Msg(total, "tip I NO, sol tip I NO, tip II OK, sol tip II NO !");
	if(ok4)
		Msg(total, "tip I NO, sol tip I NO, tip II NO, sol tip II OK !");
	
    return 0;
}
