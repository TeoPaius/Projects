// Cod executat in inte de main
#include <iostream>
using namespace std;

int F(string nume)
{
    cout << "Salut " << nume << '\n';
    return 0;
}

int x = F("Daniela");

//ifstream is("sir.in");
//FILE* is = fopen("sir.in", "r");

int main()
{
    cout << "Intrare in main()\n";
    return 0;
}
