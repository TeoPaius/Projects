// Sursa 100 p - Pit-Rada Ionel Vasile
#include<fstream>
using namespace std;

int P,i,x=0,y=0,s=0,xm=0,xM=0,ym=0,yM=0,sens;
char a,b,c;

int main()
{
	ifstream f1("ape.in",ios::in);
	ofstream f2("ape.out",ios::out);
	f1>>P;
	f1>>a;
	c=a;
	for (i=2;i<=P+1;i++)
	{
		if (i>P)b=c;
		else f1>>b;
		if (a=='N')
			switch (b)
			{
				case 'N' : {s=s-x-1; y++; break;}
				case 'E' : {x++; break;}
				case 'V' : {s=s-x-1; x--; break;}
			}
		else 	
		if (a=='V')
			switch (b)
			{
				case 'N' : {y++; break;}
				case 'V' : {x--; break;}
				case 'S' : {s=s+x; y--; break;}
			}
		else 	
		if (a=='S')
			switch (b)
			{
				case 'S' : {s=s+x; y--; break;}
				case 'V' : {x--; break;}
				case 'E' : {s=s+x; x++; break;}
			}
		else	
			switch (b)
			{
				case 'S' : {y--; break;}
				case 'E' : {x++; break;}
				case 'N' : {s=s-x-1; y++; break;}
			}
		if (x>xM) xM=x;
		if (x<xm) xm=x;
		if (y>yM) yM=y;
		if (y<ym) ym=y;
		a=b;
	}
	f2<<(xM-1-xm)<<" "<<(yM-1-ym)<<" ";
	
	if (s<0){ sens=1; s=-s; s=s-P;}
	else sens=0;
	f2<<sens<<" "<<s<<endl;
	f1.close();
	f2.close();
	return 0;
}
		