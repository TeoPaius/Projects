#include "mywindow.h"

MyWindow::MyWindow(QWidget *parent) :
    QWidget(parent)
{

}
