#!/bin/bash
if [ $1 = "des" ];
	then
		echo des pa ci to
fi
